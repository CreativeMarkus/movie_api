console.log('Hello Node!');

console.log('Goodbye.');